<?php
/*
 privacy.php
 Function: アクセスしてくれた嬉しさのあまりメールを送る
 Author: Akihiko SHIRAI
 2018/3/20 For TEPIA 2018
*/
/*アクセスしてくれた嬉しさのあまりメールを送る*/
mail("aki+MGAX17@shirai.la", "Manga Generator KAI プライバシーポリシーにアクセスがありました！", "リモートアドレス".$_SERVER['REMOTE_ADDR']."\r  User Agent:".$_SERVER['HTTP_USER_AGENT']."\r アクセスしたURL ".(empty($_SERVER["HTTPS"]) ? "http://" : "https://").$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"], "From: aki+MGAX17@shirai.la");

?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<link rel="icon" href="https://manga.style/favicon.ico">
<link rel="stylesheet" href="style.css"  />
  <title>Manga Generator K.A.I.</title>

  <meta property="og:url"           content="<?php print empty($_SERVER["HTTPS"]);?>" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="Manga Generator K.A.I." />
  <meta property="og:description"   content="Generated image of your manga!" />

<!-- Google Tag Manager for manga.style -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N8RMJR7');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) manga.style-->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N8RMJR7"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    <!-- facebook -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.12&appId=178928332755710&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
    
<div id="wrapper" class="clearfix">
 <header>Manga Generator K.A.I.</header>

<article>
Manga Generatorコンソーシアムは、ソーシャルメディアの利用において、本ポリシーを定め、遵守いたします。</br>

<b>基本方針</b></br>

Manga Generatorコンソーシアムは、ソーシャルメディアの世界においても倫理を遵守いたします。Manga Generatorコンソーシアムに所属する社員、役員、臨時雇用者、契約雇用者、派遣スタッフ、アルバイト、その他の協力者の方々がソーシャルメディアで情報発信をする際には、一人ひとりが良識ある社会人として、自覚と責任を持って利用するものとします。</br>

私たちは、「表現の自由」を尊重するのはもちろんのこととして、ソーシャルメディアへ の情報発信によって読者・利用者の皆さまとの適切なコミュニケーション・情報共有を行い、より良い関係を構築していきたいと願っています。その前提として、発信内容によっては、社会に対して少なからず影響を与えるものであることを十分認識すること、あらゆる背景や事情を持つ不特定多数の利用者がアクセスできること、およびいったん発信された情報は完全に削除できないことなども踏まえて、適切な方法で利用します。</br>

<b>公式アカウントについて</b></br>

Manga Generatorコンソーシアム関連のソーシャルメディアにおける公式アカウントは、各部署の責任者が設置を認め、正式に登録されたFacebook、Twitterです。</br>
    
なお、公式アカウント上で発信されている内容がそのまますべてManga Generatorコンソーシアムとしての見解・発表であるとは限りません。</br>

<b>お問い合わせ窓口</b></br>

Manga Generatorコンソーシアムの活動及びソーシャルメディアについてのご意見・お問い合わせは、manga (at) shirai.la までお願いいたします。TEPIAにおける個人情報の取り扱いにつきましては、<a href="https://www.tepia.jp/privacy">TEPIAのプライバシーポリシー</a>に準じます。</br>
    
</article>
     

    
    <footer>
                &#169; <?php
                $since = 2018;
                if($since = date('Y')){
                                 echo $since;
                                 }else{
                                 echo $since . '-' . date('Y');
                                 }
                ?> Manga Generator consortium / KAIT Shirai Lab / Progmind, Inc. All Rights Reserved. 
</footer>
    </div>
 </body>
</html>