<?php 
// data.php
// Function: Unity Appからのデータ受信
// 送信箇所: https://github.com/progmind/MG_Unity_TEPIA/blob/json_issue/Assets/Scripts/Game/PlayData.cs#L82-L87
// History: Created 2018/3/20 Akihiko
// Updated 2018/5/7 Akihiko
// このメール配信は開発用です。
// 最終的にはGoogle Spreadsheetに移行したい
// https://github.com/progmind/MG_Unity_TEPIA/issues/16
// なお、GMO ServerによるPHPメール送信ですが、レンタルサーバーのセキュリティポリシー変更により$to      = 'noriyuki.yamamoto@progmind.jp'; は受け付けられないようでした。
//$to      = 'noriyuki.yamamoto@progmind.jp';
$to      = 'aki+tepia@shirai.la';
$subject = 'JSON received';
$message = '';
$headers = 'From: manga@shirai.la' . "\r\n" .
    'Reply-To: manga@shirai.la' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

foreach( $_GET as $key => $value ) {
 $message = $message . htmlspecialchars($key) . "=" . htmlspecialchars($value) . "\r\n";
}

mail($to, $subject, $message, $headers);

?><!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<link rel="icon" href="https://manga.style/favicon.ico">
<link rel="stylesheet" href="https://manga.style/TEPIA/style.css"  />
  <title>Manga Generator K.A.I.</title>

  <meta property="og:url"           content="https://manga.style/TEPIA/data.php" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="Manga Generator K.A.I. data sending" />
  <meta property="og:description"   content="Generated image of your manga!" />
  

<!-- Google Tag Manager for manga.style -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N8RMJR7');</script>
<!-- End Google Tag Manager -->
</head>
<body><?php /*Analytics();*/ ?>
<!-- Google Tag Manager (noscript) manga.style-->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N8RMJR7"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div id="wrapper" class="clearfix">
 <header>Manga Generator K.A.I . Data Receiver</header>
 <article>
<?php
// https://manga.style/TEPIA/data.php?play_at=20180319123627&Language=EN&Head_Y=-1.0&option=ENKids&story1=lavalE&story2=TottoriE&story3=InsekiE&selectedStory=InsekiE
?>
<b>play_at</b> =  <?php print $_GET['play_at']; ?> </br>
<b>Language </b> =  <?php print $_GET['Language']; ?> </br>
<b>Head_Y</b> =  <?php print $_GET['Head_Y']; ?> </br>
<b>option</b> =  <?php print $_GET['option']; ?> </br>
<b>story1</b> =  <?php print $_GET['story1']; ?> </br>
<b>story2</b> =  <?php print $_GET['story2']; ?> </br>
<b>story3</b> =  <?php print $_GET['story3']; ?> </br>
<b>selectedStory</b> =  <?php print $_GET['selectedStory']; ?> </br>
<b>SNSOK</b> =  <?php print $_GET['SNSOK']; ?> </br>

 </article>
    
    <article><a href="https://manga.style/TEPIA/privacy.php">Privacy Policy</a></article>
    <footer>
                &#169; <?php
                $since = 2018;
                if($since = date('Y')){
                                 echo $since;
                                 }else{
                                 echo $since . '-' . date('Y');
                                 }
                ?> Manga Generator consortium / KAIT Shirai Lab / Progmind, Inc. All Rights Reserved. 
</footer>
    </div>
 </body>
</html>