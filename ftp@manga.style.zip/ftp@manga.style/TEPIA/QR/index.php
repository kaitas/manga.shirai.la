<?php
/*
 TEPIA/QR/index.php
 Function: 
 Author: Akihiko SHIRAI
 2017/7/1 Created by Akihiko from AX17 Manga Generator JUMP VR ランディングページ
 2018/3/20 For TEPIA 2018

*/
//include_once "../../adm/inc.php";
//include_once "../include_AX17.php";


//もしGETでiが渡されていない場合は飛ばす
if (!isset($_GET['i'])) {
    //不正アクセスを飛ばす
    header('Location: https://manga.style/');
}

/*アクセスしてくれた嬉しさのあまりメールを送る*/
//mail("aki+MGAX17@shirai.la", "Manga Generator JUMP VR のQRにアクセスがありました！", "リモートアドレス".$_SERVER['REMOTE_ADDR']."\r  User Agent:".$_SERVER['HTTP_USER_AGENT']."\r アクセスしたURL ".(empty($_SERVER["HTTPS"]) ? "http://" : "https://").$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"], "From: aki+MGAX17@shirai.la");

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<link rel="icon" href="https://manga.style/favicon.ico">
<link rel="stylesheet" href="https://manga.style/TEPIA/style.css"  />
  <title>Manga Generator K.A.I.</title>

  <meta property="og:url"           content="https://manga.style/TEPIA/QR/?i=<?php print $_GET['i']?>" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="Manga Generator K.A.I." />
  <meta property="og:description"   content="Generated image of your manga!" />
  <meta property="og:image"         content="https://mangagenerator.s3.amazonaws.com/<?php print $_GET['i']?>" />

<!-- Google Tag Manager for manga.style -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N8RMJR7');</script>
<!-- End Google Tag Manager -->
</head>
<body><?php /*Analytics();*/ ?>
<!-- Google Tag Manager (noscript) manga.style-->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N8RMJR7"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    <!-- facebook -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.12&appId=178928332755710&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
    
<div id="wrapper" class="clearfix">
 <header>Manga Generator K.A.I.</header>

    <a href="https://twitter.com/MangaGenKai?ref_src=twsrc%5Etfw" class="twitter-follow-button" data-show-count="false">Follow @MangaGenKai</a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<div class="fb-like" data-href="https://www.facebook.com/pg/MangaGenerator/photos/" data-layout="button_count" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div> 
    
    <div><h1>Thanks for your playing!</h1></div>
 <article>
     <img width="100%" src="https://mangagenerator.s3.amazonaws.com/<?php print $_GET['i']?>"> </br>
 </article>
     
    <div class="fb-page" data-href="https://www.facebook.com/MangaGenerator/" data-tabs="timeline" data-width="500" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/MangaGenerator/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/MangaGenerator/">Manga Generator</a></blockquote></div>
    
    <!--
     <article id="button">    
        <form method="get" action="https://questant.jp/q/MGAEX">
            <input type="hidden" name="id" value="<?=$_GET['i']?>">
            <input type="submit" value="Give your feedback to Manga Generator!" class="button mg">
        </form>
    </article>
-->
    <article><a href="https://manga.style/TEPIA/privacy.php">Privacy Policy</a></article>
    <footer>
                &#169; <?php
                $since = 2018;
                if($since = date('Y')){
                                 echo $since;
                                 }else{
                                 echo $since . '-' . date('Y');
                                 }
                ?> Manga Generator consortium / KAIT Shirai Lab / Progmind, Inc. All Rights Reserved. 
</footer>
    </div>
 </body>
</html>